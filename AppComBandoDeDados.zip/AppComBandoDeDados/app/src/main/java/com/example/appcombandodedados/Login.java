package com.example.appcombandodedados;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.appcombandodedados.ui.ConexaodoMySql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login extends AppCompatActivity {

    EditText usuario, senha;
    Button btLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        usuario = findViewById(R.id.usuario);
        senha = findViewById(R.id.senha);
        btLogin = findViewById(R.id.btLogin);

        btLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                try {
                    Connection con = ConexaodoMySql.conectar();
                    String sql = "SELECT * FROM login WHERE usuario = ? AND senha = UPPER(MD5(?))";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setString(1, usuario.getText().toString());
                    stmt.setString(2, senha.getText().toString());
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()){
                        Intent menu = new Intent(Login.this, MainActivity.class);
                        startActivity(menu);
                        finish();
                    }else {
                        Toast.makeText(getApplication(), "Usuário ou senha inválidos", Toast.LENGTH_SHORT).show();
                    }


                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }

            });
    }
}